package com.user;

public @interface BindView {
}
