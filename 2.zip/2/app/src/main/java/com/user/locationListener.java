package com.user;

import android.location.LocationListener;

public interface locationListener extends LocationListener {
}
