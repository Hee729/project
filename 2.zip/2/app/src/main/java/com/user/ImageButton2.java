package com.user;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;


/**
 * 购物车的最佳实现（分店铺）
 * 主要功能：1.刷新数据；
 * 2.单选、全选；
 * 3.合计；
 * 4.删除；
 * 5.商品数量加减；
 */
public class ImageButton2 extends AppCompatActivity {

    private static final String TAG = "ImageButton2";

    @BindView(R.id.tv_titlebar_center)
    TextView tvTitlebarCenter;
    @BindView(R.id.tv_titlebar_right)
    TextView tvTitlebarRight;
    @BindView(R.id.elv_shopping_car)
    ExpandableListView elvShoppingCar;
    @BindView(R.id.iv_select_all)
    ImageView ivSelectAll;
    @BindView(R.id.ll_select_all)
    LinearLayout llSelectAll;
    @BindView(R.id.btn_order)
    Button btnOrder;
    @BindView(R.id.btn_delete)
    Button btnDelete;
    @BindView(R.id.tv_total_price)
    TextView tvTotalPrice;
    @BindView(R.id.rl_total_price)
    RelativeLayout rlTotalPrice;
    @BindView(R.id.rl)
    RelativeLayout rl;
    @BindView(R.id.iv_no_contant)
    ImageView ivNoContant;
    @BindView(R.id.rl_no_contant)
    RelativeLayout rlNoContant;
    @BindView(R.id.tv_titlebar_left)
    TextView tvTitlebarLeft;

    //模拟的购物车数据（实际开发中使用后台返回的数据）
    /*public String shoppingCarData = "{\n" +
            "    \"code\": 200,\n" +
            "    \"datas\": [\n" +
            "        {\n" +
            "            \"goods\": [\n" +
            "                {\n" +
            "                    \"goods_id\": \"111111\",\n" +
            "                    \"goods_image\": \"https://image.homeplus.kr/td/2ddeb75e-a4ab-4649-8ebc-e6a70b2dba99\",\n" +
            "                    \"goods_name\": \"소용량 매일매일 바나나 4입(봉) 440G\",\n" +
            "                    \"goods_num\": \"1\",\n" +
            "                    \"goods_price\": \"1990\"\n" +
            "                }\n" +
            "            ],\n" +
            "            \"store_id\": \"1\",\n" +
            "            \"store_name\": \"재소.과일\"\n" +
            "        },\n" +
            "        {\n" +
            "            \"goods\": [\n" +
            "                {\n" +
            "                    \"goods_id\": \"222221\",\n" +
            "                    \"goods_image\": \"https://nutrilabs.co.kr/web/product/big/202203/ead97f8ef52dfcd1165e20dc86c4f061.jpg\",\n" +
            "                    \"goods_name\": \"뉴트리랩스] 비타민D 2000IU(2개월분)\",\n" +
            "                    \"goods_num\": \"2\",\n" +
            "                    \"goods_price\": \"39900\"\n" +
            "                },\n" +
            "                {\n" +
            "                    \"goods_id\": \"222222\",\n" +
            "                    \"goods_image\": \"https://image.homeplus.kr/td/2cd24db8-e5fe-4951-9dd5-a6ef76eb76fa\",\n" +
            "                    \"goods_name\": \"매일먹는 진짜 홍삼 10포*3입\",\n" +
            "                    \"goods_num\": \"2\",\n" +
            "                    \"goods_price\": \"38900\"\n" +
            "                }\n" +
            "            ],\n" +
            "            \"store_id\": \"2\",\n" +
            "            \"store_name\": \"건강식품\"\n" +
            "        },\n" +
            "        {\n" +
            "            \"goods\": [\n" +
            "                {\n" +
            "                    \"goods_id\": \"333331\",\n" +
            "                    \"goods_image\": \"https://image.homeplus.kr/td/d41ed1aa-8a9f-4a1f-ac0f-28f9b72756a8\",\n" +
            "                    \"goods_name\": \"홈런볼 41G*4입\",\n" +
            "                    \"goods_num\": \"3\",\n" +
            "                    \"goods_price\": \"3390\"\n" +
            "                },\n" +
            "                {\n" +
            "                    \"goods_id\": \"333332\",\n" +
            "                    \"goods_image\": \"https://image.homeplus.kr/td/19c057d9-8d52-44f6-ab2d-2247c50ce715\",\n" +
            "                    \"goods_name\": \"쌀과자 300G\",\n" +
            "                    \"goods_num\": \"3\",\n" +
            "                    \"goods_price\": \"4490\"\n" +
            "                },\n" +
            "                {\n" +
            "                    \"goods_id\": \"333333\",\n" +
            "                    \"goods_image\": \"https://image.homeplus.kr/td/05f315d6-6ad9-493c-9f35-979693b045e9\",\n" +
            "                    \"goods_name\": \"허쉬 초콜릿 쿠기 144G\",\n" +
            "                    \"goods_num\": \"3\",\n" +
            "                    \"goods_price\": \"4390\"\n" +
            "                }\n" +
            "            ],\n" +
            "            \"store_id\": \"3\",\n" +
            "            \"store_name\": \"과자\"\n" +
            "        }\n" +
            "    ]\n" +
            "}";*/

    public String shoppingCarData;

    private List<ShoppingCarDataBean.DatasBean> datas;
    private Context context;
    private ShoppingCarAdapter shoppingCarAdapter;

    private com.Goods.GoodsBeanDAO goodsBeanDAO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.imagebutton2);

        goodsBeanDAO = MyDataBase.getInstance(this).GoodsBeanDao();
        ButterKnife.bind(this);
        context = this;
        initExpandableListView();
        initData();
        
    }

    @OnClick({R.id.tv_titlebar_left, R.id.tv_titlebar_right,R.id.btn_order})

    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.tv_titlebar_left://转路径
                if (context instanceof Activity) {
                    Intent intent = new Intent(context, ImageButton1.class);
                    context.startActivity(intent);
                    ((Activity) context).finish();
                }
                break;
            case R.id.tv_titlebar_right://编辑
                String edit = tvTitlebarRight.getText().toString().trim();
                if (edit.equals("편집")) {
                    tvTitlebarRight.setText("완료");
                    rlTotalPrice.setVisibility(View.GONE);
                    btnOrder.setVisibility(View.GONE);
                    btnDelete.setVisibility(View.VISIBLE);
                } else {
                    tvTitlebarRight.setText("편집");
                    rlTotalPrice.setVisibility(View.VISIBLE);
                    btnOrder.setVisibility(View.VISIBLE);
                    btnDelete.setVisibility(View.GONE);
                }
                break;
            default:
                break;
        }
    }
    /**
     * 初始化数据
     */
    private void initData() {
        //使用Gson解析购物车数据，
        //ShoppingCarDataBean为bean类，Gson按照bean类的格式解析数据
        /**
         * 实际开发中，通过请求后台接口获取购物车数据并解析
         */
        Gson gson = new Gson();
        ShoppingCarDataBean shoppingCarDataBean = gson.fromJson(shoppingCarData, ShoppingCarDataBean.class);

        //datas = shoppingCarDataBean.getDatas();

        datas = new ArrayList<>();

        List<GoodsBean> goodsBeanList = goodsBeanDAO.getAllGoodss();

        Log.i(TAG, "initData: " + new Gson().toJson(goodsBeanList));

        goodsBeanList.forEach(item -> {

            ShoppingCarDataBean.DatasBean.GoodsBean newItem = new ShoppingCarDataBean.DatasBean.GoodsBean();
            newItem.setGoods_id(item.getGoods_id());
            newItem.setGoods_image(item.getGoods_image());
            newItem.setGoods_name(item.getGoods_name());
            newItem.setGoods_num(item.getGoods_num());
            newItem.setGoods_price(item.getGoods_price());

            if (datas.size() == 0) {
                ShoppingCarDataBean.DatasBean datasBean = new ShoppingCarDataBean.DatasBean();
                datasBean.setStore_id(item.getStore_id());
                datasBean.setStore_name(item.getStore_name());
                List<ShoppingCarDataBean.DatasBean.GoodsBean> list = new ArrayList<>();
                list.add(newItem);
                datasBean.setGoods(list);
                datas.add(datasBean);
                return;
            }

            for (int i = 0; i < datas.size(); i++) {
                if (datas.get(i).getStore_id().equals(item.getStore_id())) {
                    datas.get(i).getGoods().add(newItem);
                    return;
                }
            }

            //如果没有就新增一项
            ShoppingCarDataBean.DatasBean datasBean = new ShoppingCarDataBean.DatasBean();
            datasBean.setStore_id(item.getStore_id());
            datasBean.setStore_name(item.getStore_name());
            List<ShoppingCarDataBean.DatasBean.GoodsBean> list = new ArrayList<>();
            list.add(newItem);
            datasBean.setGoods(list);
            datas.add(datasBean);

        });

        initExpandableListViewData(datas);
    }

    /**
     * 初始化ExpandableListView
     * 创建数据适配器adapter，并进行初始化操作
     */
    private void initExpandableListView() {
        shoppingCarAdapter = new ShoppingCarAdapter(context, llSelectAll, ivSelectAll, btnOrder, btnDelete, rlTotalPrice, tvTotalPrice);
        elvShoppingCar.setAdapter(shoppingCarAdapter);

        //删除的回调
        shoppingCarAdapter.setOnDeleteListener(new ShoppingCarAdapter.OnDeleteListener() {
            @Override
            public void onDelete() {
                initDelete();
                /**
                 * 实际开发中，在此请求删除接口，删除成功后，
                 * 通过initExpandableListViewData（）方法刷新购物车数据。
                 * 注：通过bean类中的DatasBean的isSelect_shop属性，判断店铺是否被选中；
                 *                  GoodsBean的isSelect属性，判断商品是否被选中，
                 *                  （true为选中，false为未选中）
                 */

            }
        });

        //修改商品数量的回调
        shoppingCarAdapter.setOnChangeCountListener(new ShoppingCarAdapter.OnChangeCountListener() {
            @Override
            public void onChangeCount(String goods_id) {
                /**
                 * 实际开发中，在此请求修改商品数量的接口，商品数量修改成功后，
                 * 通过initExpandableListViewData（）方法刷新购物车数据。
                 */

                Log.i(TAG, "onChangeCount: " + goods_id);

            }
        });
    }

    /**
     * 初始化ExpandableListView的数据
     * 并在数据刷新时，页面保持当前位置
     *
     * @param datas 购物车的数据
     */
    private void initExpandableListViewData(List<ShoppingCarDataBean.DatasBean> datas) {
        if (datas != null && datas.size() > 0) {
            //刷新数据时，保持当前位置
            shoppingCarAdapter.setData(datas);

            //使所有组展开
            for (int i = 0; i < shoppingCarAdapter.getGroupCount(); i++) {
                elvShoppingCar.expandGroup(i);
            }

            //使组点击无效果
            elvShoppingCar.setOnGroupClickListener(new ExpandableListView.OnGroupClickListener() {

                @Override
                public boolean onGroupClick(ExpandableListView parent, View v, int groupPosition, long id) {
                    return true;
                }
            });

            tvTitlebarRight.setVisibility(View.VISIBLE);
            tvTitlebarRight.setText("편집");
            rlNoContant.setVisibility(View.GONE);
            elvShoppingCar.setVisibility(View.VISIBLE);
            rl.setVisibility(View.VISIBLE);
            rlTotalPrice.setVisibility(View.VISIBLE);
            btnOrder.setVisibility(View.VISIBLE);
            btnDelete.setVisibility(View.GONE);
        } else {
            tvTitlebarRight.setVisibility(View.GONE);
            rlNoContant.setVisibility(View.VISIBLE);
            elvShoppingCar.setVisibility(View.GONE);
            rl.setVisibility(View.GONE);
        }
    }

    /**
     * 判断是否要弹出删除的dialog
     * 通过bean类中的DatasBean的isSelect_shop属性，判断店铺是否被选中；
     * GoodsBean的isSelect属性，判断商品是否被选中，
     */
    private void initDelete() {
        //判断是否有店铺或商品被选中3
        
        //true为有，则需要刷新数据；反之，则不需要；
        boolean hasSelect = false;
        //创建临时的List，用于存储没有被选中的购物车数据
        List<ShoppingCarDataBean.DatasBean> datasTemp = new ArrayList<>();

        for (int i = 0; i < datas.size(); i++) {
            List<ShoppingCarDataBean.DatasBean.GoodsBean> goods = datas.get(i).getGoods();
            boolean isSelect_shop = datas.get(i).getIsSelect_shop();

            if (isSelect_shop) {
                hasSelect = true;
                //跳出本次循环，继续下次循环。
                continue;
            } else {
                datasTemp.add(datas.get(i).clone());
                datasTemp.get(datasTemp.size() - 1).setGoods(new ArrayList<ShoppingCarDataBean.DatasBean.GoodsBean>());
            }

            for (int y = 0; y < goods.size(); y++) {
                ShoppingCarDataBean.DatasBean.GoodsBean goodsBean = goods.get(y);
                boolean isSelect = goodsBean.getIsSelect();

                if (isSelect) {
                    hasSelect = true;
                } else {
                    datasTemp.get(datasTemp.size() - 1).getGoods().add(goodsBean);
                }
            }
        }


        if (hasSelect) {
            showDeleteDialog(datasTemp);
        } else {
            ToastUtil.makeText(context, "삭제할 상품을 선택하기");
        }
    }


    /**
     * 展示删除的dialog（可以自定义弹窗，不用删除即可）
     *
     * @param datasTemp
     */
    private void showDeleteDialog(final List<ShoppingCarDataBean.DatasBean> datasTemp) {
        View view = View.inflate(context, R.layout.dialog_two_btn, null);
        final RoundCornerDialog roundCornerDialog = new RoundCornerDialog(context, 0, 0, view, R.style.RoundCornerDialog);
        roundCornerDialog.show();
        roundCornerDialog.setCanceledOnTouchOutside(false);// 设置点击屏幕Dialog不消失
        roundCornerDialog.setOnKeyListener(keylistener);//设置点击返回键Dialog不消失

        TextView tv_message = (TextView) view.findViewById(R.id.tv_message);
        TextView tv_logout_confirm = (TextView) view.findViewById(R.id.tv_logout_confirm);
        TextView tv_logout_cancel = (TextView) view.findViewById(R.id.tv_logout_cancel);
        tv_message.setText("상품을 삭제하시겠습니까?？");

        //确定
        tv_logout_confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                roundCornerDialog.dismiss();
                datas = datasTemp;

                // 删除所有数据库数据
                goodsBeanDAO.deleteAll();

                if (datas != null && datas.size() > 0) {//如果有被选中的
                 /*
                  实际开发中，如果有被选中的商品，
                  则跳转到确认订单页面，完成后续订单流程。
                 */
                    //ToastUtil.makeText(context, "주문 확인 페이지로 이동");

                    com.Goods.GoodsBeanDAO goodsBeanDAO;
                    goodsBeanDAO = MyDataBase.getInstance(context).GoodsBeanDao();

                    datas.forEach(item -> {

                        item.getGoods().forEach(item1 -> {

                            GoodsBean goodsBean = new GoodsBean();
                            goodsBean.setStore_id(item.getStore_id());
                            goodsBean.setStore_name(item.getStore_name());
                            goodsBean.setGoods_id(item1.getGoods_id());
                            goodsBean.setGoods_name(item1.getGoods_name());
                            goodsBean.setGoods_image(item1.getGoods_image());
                            goodsBean.setGoods_price(item1.getGoods_price());
                            goodsBean.setGoods_num(item1.getGoods_num());

                            goodsBeanDAO.insertGoods(goodsBean);
                        });
                    });
                }

                initExpandableListViewData(datas);
            }
        });
        //取消
        tv_logout_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                roundCornerDialog.dismiss();
            }
        });
    }

    DialogInterface.OnKeyListener keylistener = new DialogInterface.OnKeyListener() {
        public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
            if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
                return true;
            } else {
                return false;
            }
        }
    };
}
