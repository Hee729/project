package com.user;


import android.os.Bundle;

import com.user.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ViewData8 {
    public static   List<HashMap<String,Object>> data = addData();
    // 获取静态数据
    public static List<HashMap<String,Object>> addData() {
        Map<String, Object> map = new HashMap<>();
        map.put("item_displayimage", R.drawable.tv);
        map.put("item_title","루컴즈 22년 109CM TV");
        map.put("item_size","");
        map.put("item_id","888881");
        map.put("store_id","8");
        map.put("store_name","가전제품");
        map.put("item_money","36,900원");
        map.put("item_info","평가률:90%");

        Map<String, Object> map1 = new HashMap<>();
        map1.put("item_displayimage",R.drawable.monito1r);
        map1.put("item_title","22인치 사무형 모니터");
        map1.put("item_size","");
        map1.put("item_id","888882");
        map1.put("store_id","8");
        map1.put("store_name","가전제품");
        map1.put("item_money","345,500원");
        map1.put("item_info","평가률:90%");

        Map<String, Object> map2 = new HashMap<>();
        map2.put("item_displayimage",R.drawable.vacuum);
        map2.put("item_title","테팔무선청소기 에어포스360");
        map2.put("item_size","");
        map2.put("item_id","888883");
        map2.put("store_id","8");
        map2.put("store_name","가전제품");
        map2.put("item_money","349,000원");
        map2.put("item_info"," 평가률:90%");

        Map<String, Object> map3 = new HashMap<>();
        map3.put("item_displayimage",R.drawable.washingmachine);
        map3.put("item_title","삼성 그랑데 드럼세탁기");
        map3.put("item_size","");
        map3.put("item_id","888884");
        map3.put("store_id","8");
        map3.put("store_name","가전제품");
        map3.put("item_money","806,400원");
        map3.put("item_info","평가률:90%");

        Map<String, Object> map4 = new HashMap<>();
        map4.put("item_displayimage",R.drawable.iron);
        map4.put("item_title","테팔 건조다리미");
        map4.put("item_size","");
        map4.put("item_id","888885");
        map4.put("store_id","8");
        map4.put("store_name","가전제품");
        map4.put("item_money","23,900원");
        map4.put("item_info","평가률:90%");

        Map<String, Object> map5 = new HashMap<>();
        map5.put("item_displayimage",R.drawable.steamiron);
        map5.put("item_title","짐머만 T형 스팀다리미");
        map5.put("item_size","");
        map5.put("item_id","888886");
        map5.put("store_id","8");
        map5.put("store_name","가전제품");
        map5.put("item_money","39,880원");
        map5.put("item_info","평가률:90%");

        Map<String, Object> map6 = new HashMap<>();
        map6.put("item_displayimage",R.drawable.aircleaner);
        map6.put("item_title","가정용 소형 공기청정기");
        map6.put("item_size","");
        map6.put("item_id","888887");
        map6.put("store_id","8");
        map6.put("store_name","가전제품");
        map6.put("item_money","141,550원");
        map6.put("item_info","평가률:90%");

        Map<String, Object> map7 = new HashMap<>();
        map7.put("item_displayimage",R.drawable.electrictoothbrush);
        map7.put("item_title","필립스 전동칫솔(white)");
        map7.put("item_size","");
        map7.put("item_id","888888");
        map7.put("store_id","8");
        map7.put("store_name","가전제품");
        map7.put("item_money","57,900원");
        map7.put("item_info","평가률:90%");

        List<HashMap<String, Object>> hashMaps = new ArrayList<>();
        hashMaps.add((HashMap<String, Object>) map);
        hashMaps.add((HashMap<String, Object>) map1);
        hashMaps.add((HashMap<String, Object>) map2);
        hashMaps.add((HashMap<String, Object>) map3);
        hashMaps.add((HashMap<String, Object>) map4);
        hashMaps.add((HashMap<String, Object>) map5);
        hashMaps.add((HashMap<String, Object>) map6);
        hashMaps.add((HashMap<String, Object>) map7);

        return  hashMaps;
    }

    // 通过商品的标签获取商品信息
    public static Bundle getBundle(String item_title){
        Bundle bundle=null;
        for (Map<String, Object> map:data){
            // 获取用户点击的商品,并跳转到商品详情页面
            if (map.get("item_title").equals(item_title)){
                // 传递参数
                //让hashmap实现可序列化则要定义一个实现可序列化的类。
                SerMap serMap=new SerMap();
                //传递map到SerMap 中的map，这样数据就会传递到SerMap 中的map中。
                serMap.setMap((HashMap<String, Object>) map);
                //创建Bundle对象，存放实现可序列化的SerMap
                bundle=new Bundle();
                bundle.putSerializable("listView",serMap);
            }
        }

        return bundle;
    }

}
