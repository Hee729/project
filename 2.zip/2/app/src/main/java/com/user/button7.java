package com.user;


import static android.widget.Toast.LENGTH_SHORT;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.user.ViewData;

public class button7 extends AppCompatActivity {
    private ListView listview_main;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.button7);
        initView();
    }


    // 初始化
    private void initView() {
        listview_main = findViewById(R.id.list7);
        // 数据适配器
        SimpleAdapter mSimpleAdapter = new SimpleAdapter(this, ViewData7.data, R.layout.item,
                new String[]{"item_displayimage", "item_title", "item_size", "item_money", "item_info"},
                new int[]{R.id.item_displayimage, R.id.item_title, R.id.item_size, R.id.item_money, R.id.item_info});
        listview_main.setAdapter(mSimpleAdapter);
        // item上的点击事件
        listview_main.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                TextView item_title = view.findViewById(R.id.item_title);
                Bundle bundle = ViewData7.getBundle(item_title.getText().toString());
                if (bundle != null) {
                    // 将当前Map商品信息传递到另一个界面
                    Intent intent = new Intent(button7.this, PhoneInfoActivity.class);
                    //意图放置bundle变量
                    intent.putExtras(bundle);
                    startActivity(intent);
                } else {
                    Toast.makeText(button7.this,"틀리다, 빨리 직원에게 연락해!",LENGTH_SHORT).show();

                }
            }
        });
    }
}




