package com.user;


import android.os.Bundle;

import com.user.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ViewData3 {
    public static   List<HashMap<String,Object>> data = addData();
    // 获取静态数据
    public static List<HashMap<String,Object>> addData() {
        Map<String, Object> map = new HashMap<>();
        map.put("item_displayimage", R.drawable.pet1 );
        map.put("item_title","내추럴 껌 애완간식");
        map.put("item_size","5개입");
        map.put("item_id","333331");
        map.put("store_id","3");
        map.put("store_name","애견용품");
        map.put("item_money","2,200원");
        map.put("item_info","평가률:90%");

        Map<String, Object> map1 = new HashMap<>();
        map1.put("item_displayimage",R.drawable.pet2);
        map1.put("item_title","우유 껌 애완간식");
        map1.put("item_size","5개입");
        map1.put("item_id","333332");
        map1.put("store_id","3");
        map1.put("store_name","애견용품");
        map1.put("item_money","2,400원");
        map1.put("item_info","평가률:90%");

        Map<String, Object> map2 = new HashMap<>();
        map2.put("item_displayimage",R.drawable.pet3);
        map2.put("item_title","양고기캔 애완용품");
        map2.put("item_size","200g");
        map2.put("item_id","333333");
        map2.put("store_id","3");
        map2.put("store_name","애견용품");
        map2.put("item_money","3,600원");
        map2.put("item_info","평가률:90%");

        Map<String, Object> map3 = new HashMap<>();
        map3.put("item_displayimage",R.drawable.pet4);
        map3.put("item_title","[LG생활건강]강아지 용품 탈취제");
        map3.put("item_size","500ml");
        map3.put("item_id","333334");
        map3.put("store_id","3");
        map3.put("store_name","애견용품");
        map3.put("item_money","8,900원");
        map3.put("item_info","평가률:90%");

        Map<String, Object> map4 = new HashMap<>();
        map4.put("item_displayimage",R.drawable.pet5);
        map4.put("item_title","시그니처 깔끔해서 좋은 배변패드");
        map4.put("item_size","중형400매");
        map4.put("item_id","333335");
        map4.put("store_id","3");
        map4.put("store_name","애견용품");
        map4.put("item_money","27,900원");
        map4.put("item_info","평가률:90%");

        Map<String, Object> map5 = new HashMap<>();
        map5.put("item_displayimage",R.drawable.pet6);
        map5.put("item_title","[하림펫푸드]밥이보약 영양톡톡 장");
        map5.put("item_size","60g");
        map5.put("item_id","333336");
        map5.put("store_id","3");
        map5.put("store_name","애견용품");
        map5.put("item_money","6,930원");
        map5.put("item_info","평가률:90%");

        Map<String, Object> map6 = new HashMap<>();
        map6.put("item_displayimage",R.drawable.pet7);
        map6.put("item_title","[굿데이]건강가득 닭가슴살 황태 큐브");
        map6.put("item_size","300g");
        map6.put("item_id","333337");
        map6.put("store_id","3");
        map6.put("store_name","애견용품");
        map6.put("item_money","6,490원");
        map6.put("item_info","평가률:90%");

        Map<String, Object> map7 = new HashMap<>();
        map7.put("item_displayimage",R.drawable.pet8);
        map7.put("item_title","애견간식 콜라겐 황태스틱 개껌");
        map7.put("item_size","");
        map7.put("item_id","333338");
        map7.put("store_id","3");
        map7.put("store_name","애견용품");
        map7.put("item_money","2,490원");
        map7.put("item_info","평가률:90%");

        List<HashMap<String, Object>> hashMaps = new ArrayList<>();
        hashMaps.add((HashMap<String, Object>) map);
        hashMaps.add((HashMap<String, Object>) map1);
        hashMaps.add((HashMap<String, Object>) map2);
        hashMaps.add((HashMap<String, Object>) map3);
        hashMaps.add((HashMap<String, Object>) map4);
        hashMaps.add((HashMap<String, Object>) map5);
        hashMaps.add((HashMap<String, Object>) map6);
        hashMaps.add((HashMap<String, Object>) map7);

        return  hashMaps;
    }

    // 通过商品的标签获取商品信息
    public static Bundle getBundle(String item_title){
        Bundle bundle=null;
        for (Map<String, Object> map:data){
            // 获取用户点击的商品,并跳转到商品详情页面
            if (map.get("item_title").equals(item_title)){
                // 传递参数
                //让hashmap实现可序列化则要定义一个实现可序列化的类。
                SerMap serMap=new SerMap();
                //传递map到SerMap 中的map，这样数据就会传递到SerMap 中的map中。
                serMap.setMap((HashMap<String, Object>) map);
                //创建Bundle对象，存放实现可序列化的SerMap
                bundle=new Bundle();
                bundle.putSerializable("listView",serMap);
            }
        }

        return bundle;
    }

}
