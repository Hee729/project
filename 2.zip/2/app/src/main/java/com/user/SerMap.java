package com.user;

import java.io.Serializable;
import java.util.HashMap;

public class SerMap implements Serializable {
    public HashMap<String,Object> map;
    public  SerMap(){

    }

    public void setMap(HashMap<String, Object> map) {
        this.map = map;

    }

    public HashMap<String, Object> getMap() {
        return map;
    }

}

