package com.user;


import android.os.Bundle;

import com.user.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ViewData10 {
    public static   List<HashMap<String,Object>> data = addData();
    // 获取静态数据
    public static List<HashMap<String,Object>> addData() {
        Map<String, Object> map = new HashMap<>();
        map.put("item_displayimage", R.drawable.nickelsilve);
        map.put("item_title","양은냄비 24CM");
        map.put("item_size","");
        map.put("item_id","100001");
        map.put("store_id","10");
        map.put("store_name","주방용품");
        map.put("item_money","11,500원");
        map.put("item_info","평가률:90%");

        Map<String, Object> map1 = new HashMap<>();
        map1.put("item_displayimage",R.drawable.spatula);
        map1.put("item_title","비바 실리콘 뒤집개");
        map1.put("item_size","");
        map1.put("item_id","100002");
        map1.put("store_id","10");
        map1.put("store_name","주방용품");
        map1.put("item_money","5,900원");
        map1.put("item_info","평가률:90%");

        Map<String, Object> map2 = new HashMap<>();
        map2.put("item_displayimage",R.drawable.kettle);
        map2.put("item_title","스텐 휘슬 주전자");
        map2.put("item_size","");
        map2.put("item_id","100003");
        map2.put("store_id","10");
        map2.put("store_name","주방용품");
        map2.put("item_money","16,900원");
        map2.put("item_info","평가률:90%");

        Map<String, Object> map3 = new HashMap<>();
        map3.put("item_displayimage",R.drawable.container);
        map3.put("item_title","락앤락 사각통 3.4L");
        map3.put("item_size","");
        map3.put("item_id","100004");
        map3.put("store_id","10");
        map3.put("store_name","주방용품");
        map3.put("item_money","5,900원");
        map3.put("item_info","평가률:90%");

        Map<String, Object> map4 = new HashMap<>();
        map4.put("item_displayimage",R.drawable.spoon);
        map4.put("item_title","휴대용 수제세트(블랙)");
        map4.put("item_size","");
        map4.put("item_id","100005");
        map4.put("store_id","10");
        map4.put("store_name","주방용품");
        map4.put("item_money","5,010원");
        map4.put("item_info","평가률:90%");

        Map<String, Object> map5 = new HashMap<>();
        map5.put("item_displayimage",R.drawable.vegetablechoppers);
        map5.put("item_title","스텐 야채 칼");
        map5.put("item_size","");
        map5.put("item_id","100006");
        map5.put("store_id","10");
        map5.put("store_name","주방용품");
        map5.put("item_money","14,600원");
        map5.put("item_info","평가률:90%");

        Map<String, Object> map6 = new HashMap<>();
        map6.put("item_displayimage",R.drawable.knife);
        map6.put("item_title","중화식도 주방용 중화 칼");
        map6.put("item_size","");
        map6.put("item_id","100007");
        map6.put("store_id","10");
        map6.put("store_name","주방용품");
        map6.put("item_money","14,880원");
        map6.put("item_info","평가률:90%");

        Map<String, Object> map7 = new HashMap<>();
        map7.put("item_displayimage",R.drawable.choppingboard);
        map7.put("item_title","페어 원목 칼도마꽃이");
        map7.put("item_size","");
        map7.put("item_id","100008");
        map7.put("store_id","10");
        map7.put("store_name","주방용품");
        map7.put("item_money","17,900원");
        map7.put("item_info","평가률:90%");

        List<HashMap<String, Object>> hashMaps = new ArrayList<>();
        hashMaps.add((HashMap<String, Object>) map);
        hashMaps.add((HashMap<String, Object>) map1);
        hashMaps.add((HashMap<String, Object>) map2);
        hashMaps.add((HashMap<String, Object>) map3);
        hashMaps.add((HashMap<String, Object>) map4);
        hashMaps.add((HashMap<String, Object>) map5);
        hashMaps.add((HashMap<String, Object>) map6);
        hashMaps.add((HashMap<String, Object>) map7);

        return  hashMaps;
    }

    // 通过商品的标签获取商品信息
    public static Bundle getBundle(String item_title){
        Bundle bundle=null;
        for (Map<String, Object> map:data){
            // 获取用户点击的商品,并跳转到商品详情页面
            if (map.get("item_title").equals(item_title)){
                // 传递参数
                //让hashmap实现可序列化则要定义一个实现可序列化的类。
                SerMap serMap=new SerMap();
                //传递map到SerMap 中的map，这样数据就会传递到SerMap 中的map中。
                serMap.setMap((HashMap<String, Object>) map);
                //创建Bundle对象，存放实现可序列化的SerMap
                bundle=new Bundle();
                bundle.putSerializable("listView",serMap);
            }
        }

        return bundle;
    }

}
