package com.user;


import android.os.Bundle;

import com.user.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ViewData2 {
    public static   List<HashMap<String,Object>> data = addData();
    // 获取静态数据
    public static List<HashMap<String,Object>> addData() {
        Map<String, Object> map = new HashMap<>();
        map.put("item_displayimage", R.drawable.vitamins);
        map.put("item_title","[뉴트리랩스]비타민D 2000");
        map.put("item_size","2개월분(60정)");
        map.put("item_id","222221");
        map.put("store_id","2");
        map.put("store_name","건강식품");
        map.put("item_money","39,900원");
        map.put("item_info","평가률:90%");

        Map<String, Object> map1 = new HashMap<>();
        map1.put("item_displayimage",R.drawable.redginseng);
        map1.put("item_title","매일먹는 진짜 홍삼");
        map1.put("item_id","222222");
        map1.put("store_id","2");
        map1.put("store_name","건강식품");
        map1.put("item_size","10포*3입");
        map1.put("item_money","28,900원");
        map1.put("item_info","평가률:90%");

        Map<String, Object> map2 = new HashMap<>();
        map2.put("item_displayimage",R.drawable.barleytea);
        map2.put("item_title","[정관장]홍삼정 에브리타임 밸런스");
        map2.put("item_size","10ml*20포");
        map2.put("item_id","222223");
        map2.put("store_id","2");
        map2.put("store_name","건강식품");
        map2.put("item_money","45,900원");
        map2.put("item_info"," 평가률:90%");

        Map<String, Object> map3 = new HashMap<>();
        map3.put("item_displayimage",R.drawable.bacteria1);
        map3.put("item_title","[경남제약]생유산균 알파");
        map3.put("item_size","100포");
        map3.put("item_id","222224");
        map3.put("store_id","2");
        map3.put("store_name","건강식품");
        map3.put("item_money","11,800원");
        map3.put("item_info"," 평가률:90%");

        Map<String, Object> map4 = new HashMap<>();
        map4.put("item_displayimage",R.drawable.bacteria2);
        map4.put("item_title","[CJ]식물성 유산균 패밀리");
        map4.put("item_size","1.5g*50포");
        map4.put("item_id","222225");
        map4.put("store_id","2");
        map4.put("store_name","건강식품");
        map4.put("item_money","14,900원");
        map4.put("item_info","평가률:90%");

        Map<String, Object> map5 = new HashMap<>();
        map5.put("item_displayimage",R.drawable.bacteria3);
        map5.put("item_title","[고려은단]알티지 오메가3");
        map5.put("item_size","60캡슐");
        map5.put("item_id","222226");
        map5.put("store_id","2");
        map5.put("store_name","건강식품");
        map5.put("item_money","12,900원");
        map5.put("item_info","평가률:90%");

        Map<String, Object> map6 = new HashMap<>();
        map6.put("item_displayimage",R.drawable.bacteria4);
        map6.put("item_title","세노비스 루테인 오메가3");
        map6.put("item_size","80캡");
        map6.put("item_id","222227");
        map6.put("store_id","2");
        map6.put("store_name","건강식품");
        map6.put("item_money","34,000원");
        map6.put("item_info","평가률:90%");

        Map<String, Object> map7 = new HashMap<>();
        map7.put("item_displayimage",R.drawable.bacteria5);
        map7.put("item_title","[고려은단]헬스케어 멀티 비타민");
        map7.put("item_size","120정");
        map7.put("item_id","222228");
        map7.put("store_id","2");
        map7.put("store_name","건강식품");
        map7.put("item_money","39,800원");
        map7.put("item_info"," 평가률:90%");

        List<HashMap<String, Object>> hashMaps = new ArrayList<>();
        hashMaps.add((HashMap<String, Object>) map);
        hashMaps.add((HashMap<String, Object>) map1);
        hashMaps.add((HashMap<String, Object>) map2);
        hashMaps.add((HashMap<String, Object>) map3);
        hashMaps.add((HashMap<String, Object>) map4);
        hashMaps.add((HashMap<String, Object>) map5);
        hashMaps.add((HashMap<String, Object>) map6);
        hashMaps.add((HashMap<String, Object>) map7);

        return  hashMaps;
    }

    // 通过商品的标签获取商品信息
    public static Bundle getBundle(String item_title){
        Bundle bundle=null;
        for (Map<String, Object> map:data){
            // 获取用户点击的商品,并跳转到商品详情页面
            if (map.get("item_title").equals(item_title)){
                // 传递参数
                //让hashmap实现可序列化则要定义一个实现可序列化的类。
                SerMap serMap=new SerMap();
                //传递map到SerMap 中的map，这样数据就会传递到SerMap 中的map中。
                serMap.setMap((HashMap<String, Object>) map);
                //创建Bundle对象，存放实现可序列化的SerMap
                bundle=new Bundle();
                bundle.putSerializable("listView",serMap);
            }
        }

        return bundle;
    }

}
