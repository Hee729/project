package com.user;


import android.os.Bundle;

import com.user.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ViewData11 {
    public static   List<HashMap<String,Object>> data = addData();
    // 获取静态数据
    public static List<HashMap<String,Object>> addData() {
        Map<String, Object> map = new HashMap<>();
        map.put("item_displayimage", R.drawable.diaper);
        map.put("item_title","하기스 특대형 5단계 기저귀");
        map.put("item_size","");
        map.put("item_id","110001");
        map.put("store_id","11");
        map.put("store_name","유아용품");
        map.put("item_money","39,900원");
        map.put("item_info","평가률:90%");

        Map<String, Object> map1 = new HashMap<>();
        map1.put("item_displayimage",R.drawable.milkpowder1);
        map1.put("item_title","임페이럴드림 분유 3단계");
        map1.put("item_size","");
        map1.put("item_id","110002");
        map1.put("store_id","11");
        map1.put("store_name","유아용품");
        map1.put("item_money","17,760원");
        map1.put("item_info","평가률:90%");

        Map<String, Object> map2 = new HashMap<>();
        map2.put("item_displayimage",R.drawable.milkpowder2);
        map2.put("item_title","노발락 AC 분유 800G");
        map2.put("item_size","");
        map2.put("item_id","110003");
        map2.put("store_id","11");
        map2.put("store_name","유아용품");
        map2.put("item_money","39,000원");
        map2.put("item_info","평가률:90%");

        Map<String, Object> map3 = new HashMap<>();
        map3.put("item_displayimage",R.drawable.chopsticks);
        map3.put("item_title","쿨디노 교정용 젓가락");
        map3.put("item_size","");
        map3.put("item_id","110004");
        map3.put("store_id","11");
        map3.put("store_name","유아용품");
        map3.put("item_money","5,400원");
        map3.put("item_info","평가률:90%");

        Map<String, Object> map4 = new HashMap<>();
        map4.put("item_displayimage",R.drawable.case1);
        map4.put("item_title","신비아파트 멀티케이스(유아용)");
        map4.put("item_size","");
        map4.put("item_id","110005");
        map4.put("store_id","11");
        map4.put("store_name","유아용품");
        map4.put("item_money","4,900원");
        map4.put("item_info","평가률:90%");

        Map<String, Object> map5 = new HashMap<>();
        map5.put("item_displayimage",R.drawable.babybottle);
        map5.put("item_title","무당벌레 빨대컵 240ML");
        map5.put("item_size","");
        map5.put("item_id","110006");
        map5.put("store_id","11");
        map5.put("store_name","유아용품");
        map5.put("item_money","6,230원");
        map5.put("item_info","평가률:90%");

        Map<String, Object> map6 = new HashMap<>();
        map6.put("item_displayimage",R.drawable.breastshields);
        map6.put("item_title","유한벌리 컴포트필 수유패드 60매");
        map6.put("item_size","");
        map6.put("item_id","110007");
        map6.put("store_id","11");
        map6.put("store_name","유아용품");
        map6.put("item_money","8,500원");
        map6.put("item_info","평가률:90%");

        Map<String, Object> map7 = new HashMap<>();
        map7.put("item_displayimage",R.drawable.layette);
        map7.put("item_title","누비 동물 야광 노리개 2단계");
        map7.put("item_size","");
        map7.put("item_id","110008");
        map7.put("store_id","11");
        map7.put("store_name","유아용품");
        map7.put("item_money","9,030원");
        map7.put("item_info","평가률:90%");

        List<HashMap<String, Object>> hashMaps = new ArrayList<>();
        hashMaps.add((HashMap<String, Object>) map);
        hashMaps.add((HashMap<String, Object>) map1);
        hashMaps.add((HashMap<String, Object>) map2);
        hashMaps.add((HashMap<String, Object>) map3);
        hashMaps.add((HashMap<String, Object>) map4);
        hashMaps.add((HashMap<String, Object>) map5);
        hashMaps.add((HashMap<String, Object>) map6);
        hashMaps.add((HashMap<String, Object>) map7);

        return  hashMaps;
    }

    // 通过商品的标签获取商品信息
    public static Bundle getBundle(String item_title){
        Bundle bundle=null;
        for (Map<String, Object> map:data){
            // 获取用户点击的商品,并跳转到商品详情页面
            if (map.get("item_title").equals(item_title)){
                // 传递参数
                //让hashmap实现可序列化则要定义一个实现可序列化的类。
                SerMap serMap=new SerMap();
                //传递map到SerMap 中的map，这样数据就会传递到SerMap 中的map中。
                serMap.setMap((HashMap<String, Object>) map);
                //创建Bundle对象，存放实现可序列化的SerMap
                bundle=new Bundle();
                bundle.putSerializable("listView",serMap);
            }
        }

        return bundle;
    }

}
