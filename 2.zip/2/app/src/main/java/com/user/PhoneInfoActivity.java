package com.user;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;

import java.util.HashMap;

public class PhoneInfoActivity extends AppCompatActivity {
    private ImageView imageView_Display;
    private TextView item_title, item_size,item_money,item_info;
    private HashMap<String,Object> map;
    private Button commit;

    private String id,store_id,store_name;

    private MyDataBase myDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.listview);
        myDatabase = MyDataBase.getInstance(this);
        initView();
    }

    private void initView() {
        // 初始化控件
        imageView_Display = findViewById(R.id.item_displayimage);
        item_title = findViewById(R.id.item_title);
        item_money = findViewById(R.id.item_money);
        item_info = findViewById(R.id.item_info);
        item_size = findViewById(R.id.item_size);

        //获得意图
        Intent intent=getIntent();
        //得到数据集
        Bundle bundle=intent.getExtras();
        //获得自定义类
        SerMap serializableMap = (SerMap) bundle.get("listView");
        map=serializableMap.getMap();

        // 数据初始化
        imageView_Display.setImageResource((int)map.get("item_displayimage"));

        id = map.get("item_id").toString();
        store_name = map.get("store_name").toString();
        store_id = map.get("store_id").toString();

        GoodsBean goodsBean = new GoodsBean();
        goodsBean.setGoods_id(id);
        goodsBean.setStore_id(store_id);
        goodsBean.setStore_name(store_name);
        goodsBean.setGoods_name(map.get("item_title").toString());
        goodsBean.setGoods_price(map.get("item_money").toString().replace("원",""));
        goodsBean.setGoods_num(map.get("item_size").toString());
        goodsBean.setGoods_image((map.get("item_displayimage")).toString());

        item_title.setText(map.get("item_title").toString());
        item_money.setText(map.get("item_money").toString());
        item_info.setText(map.get("item_info").toString());
        item_size.setText(map.get("item_size").toString());

        commit = findViewById(R.id.button13);
        commit.setOnClickListener(view -> {

          GoodsBean goodsBean1 =  myDatabase.GoodsBeanDao().getGoodsById(goodsBean.getGoods_id());
          if (goodsBean1 != null){
              myDatabase.GoodsBeanDao().updateGoods(goodsBean1.getGoods_id(),(Integer.parseInt(goodsBean1.getGoods_num())+1)+"");
          }else{
              goodsBean.setGoods_num("1");
              myDatabase.GoodsBeanDao().insertGoods(goodsBean);
          }

        });

    }
}