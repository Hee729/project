package com.Goods;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;


import com.user.GoodsBean;

import java.util.List;

@Dao
public interface GoodsBeanDAO {

    @Query("SELECT * FROM Goods")
    List<GoodsBean> getAllGoodss();

    @Query("SELECT * FROM Goods WHERE goods_id = :id")
    GoodsBean getGoodsById(String id);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertGoods(GoodsBean GoodsBean);

    @Query("UPDATE Goods SET goods_num = :num WHERE goods_id = :id")
    void updateGoods(String id, String num);

    @Update(onConflict =  OnConflictStrategy.REPLACE)
    void updateGoodss(GoodsBean... Goodss);

    @Query("DELETE FROM Goods WHERE goods_id = :id")
    void deleteGoodsById(String id);

    @Delete
    void deleteGoodss(GoodsBean... Goodss);

    @Query("DELETE FROM Goods")
    void deleteAll();

    
}
