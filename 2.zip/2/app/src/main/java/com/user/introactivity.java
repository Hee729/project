package com.user;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import androidx.appcompat.app.AppCompatActivity;

public class introactivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.introactivity); //xml , java 소스 연결
        Handler handler = new Handler();
        handler.postDelayed(() -> {
            Intent intent = new Intent (getApplicationContext(), MainActivity.class);
            startActivity(intent); //인트로 실행 후 바로 MainActivity로 넘어감.
            finish();
        },2000);
}
    @Override
    protected void onPause() {
        super.onPause();
        finish();
    }
}



