package com.user;

import android.app.Application;

import com.kakao.sdk.common.KakaoSdk;

public class kakaoApplication extends Application{

    @Override
    public void onCreate() {
       super.onCreate();
       KakaoSdk.init(this,"4e36fb9a0b1ca26b8560b1c837f5722e");

    }
}