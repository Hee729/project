package com.user;


import android.os.Bundle;

import com.user.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ViewData5 {
    public static   List<HashMap<String,Object>> data = addData();
    // 获取静态数据
    public static List<HashMap<String,Object>> addData() {
        Map<String, Object> map = new HashMap<>();
        map.put("item_displayimage", R.drawable.meat1);
        map.put("item_title","왕특 손질 간고등어(노르웨이)");
        map.put("item_size","1마리당");
        map.put("item_id","555551");
        map.put("store_id","5");
        map.put("store_name","수산.육류");
        map.put("item_money","3,890원");
        map.put("item_info","  평가률:90%");

        Map<String, Object> map1 = new HashMap<>();
        map1.put("item_displayimage",R.drawable.meat2);
        map1.put("item_title","항공직송 생연어(횟감용)노르웨이산");
        map1.put("item_size","100g");
        map1.put("item_id","555552");
        map1.put("store_id","5");
        map1.put("store_name","수산.육류");
        map1.put("item_money","3,790원");
        map1.put("item_info","평가률:90%");

        Map<String, Object> map2 = new HashMap<>();
        map2.put("item_displayimage",R.drawable.meat3);
        map2.put("item_title","안심한우 등심(1+등급)소고기");
        map2.put("item_size","100g");
        map2.put("item_id","555553");
        map2.put("store_id","5");
        map2.put("store_name","수산.육류");
        map2.put("item_money","9,305원");
        map2.put("item_info"," 평가률:90%");

        Map<String, Object> map3 = new HashMap<>();
        map3.put("item_displayimage",R.drawable.meat4);
        map3.put("item_title","안심한우 목살 국거리용/소고기");
        map3.put("item_size","100g");
        map3.put("item_id","555554");
        map3.put("store_id","5");
        map3.put("store_name","수산.육류");
        map3.put("item_money","3,804원");
        map3.put("item_info","평가률:90%");

        Map<String, Object> map4 = new HashMap<>();
        map4.put("item_displayimage",R.drawable.meat5);
        map4.put("item_title","서해안 제철 숫꽃게 선물세트");
        map4.put("item_size","3kg");
        map4.put("item_id","555555");
        map4.put("store_id","5");
        map4.put("store_name","수산.육류");
        map4.put("item_money","72,900원");
        map4.put("item_info","평가률:90%");

        Map<String, Object> map5 = new HashMap<>();
        map5.put("item_displayimage",R.drawable.meat6);
        map5.put("item_title","일품포크 돼지삼겹살");
        map5.put("item_size","100g");
        map5.put("item_id","555556");
        map5.put("store_id","5");
        map5.put("store_name","수산.육류");
        map5.put("item_money","2,790원");
        map5.put("item_info"," 평가률:90%");

        Map<String, Object> map6 = new HashMap<>();
        map6.put("item_displayimage",R.drawable.meat7);
        map6.put("item_title","통영 해산물 냉동 굴");
        map6.put("item_size","1kg");
        map6.put("item_id","555557");
        map6.put("store_id","5");
        map6.put("store_name","수산.육류");
        map6.put("item_money","15,600원");
        map6.put("item_info","평가률:90%");

        Map<String, Object> map7 = new HashMap<>();
        map7.put("item_displayimage",R.drawable.meat8);
        map7.put("item_title","완도전복(대)");
        map7.put("item_size","5마리");
        map7.put("item_id","555558");
        map7.put("store_id","5");
        map7.put("store_name","수산.육류");
        map7.put("item_money","11,000원");
        map7.put("item_info","평가률:90%");

        List<HashMap<String, Object>> hashMaps = new ArrayList<>();
        hashMaps.add((HashMap<String, Object>) map);
        hashMaps.add((HashMap<String, Object>) map1);
        hashMaps.add((HashMap<String, Object>) map2);
        hashMaps.add((HashMap<String, Object>) map3);
        hashMaps.add((HashMap<String, Object>) map4);
        hashMaps.add((HashMap<String, Object>) map5);
        hashMaps.add((HashMap<String, Object>) map6);
        hashMaps.add((HashMap<String, Object>) map7);

        return  hashMaps;
    }

    // 通过商品的标签获取商品信息
    public static Bundle getBundle(String item_title){
        Bundle bundle=null;
        for (Map<String, Object> map:data){
            // 获取用户点击的商品,并跳转到商品详情页面
            if (map.get("item_title").equals(item_title)){
                // 传递参数
                //让hashmap实现可序列化则要定义一个实现可序列化的类。
                SerMap serMap=new SerMap();
                //传递map到SerMap 中的map，这样数据就会传递到SerMap 中的map中。
                serMap.setMap((HashMap<String, Object>) map);
                //创建Bundle对象，存放实现可序列化的SerMap
                bundle=new Bundle();
                bundle.putSerializable("listView",serMap);
            }
        }

        return bundle;
    }

}
