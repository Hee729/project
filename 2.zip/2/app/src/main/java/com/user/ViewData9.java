package com.user;


import android.os.Bundle;

import com.user.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ViewData9 {
    public static   List<HashMap<String,Object>> data = addData();
    // 获取静态数据
    public static List<HashMap<String,Object>> addData() {
        Map<String, Object> map = new HashMap<>();
        map.put("item_displayimage", R.drawable.mouse);
        map.put("item_title","LG 6버튼 유선마우스");
        map.put("item_size","");
        map.put("item_id","999991");
        map.put("store_id","9");
        map.put("store_name","전자기기");
        map.put("item_money","26,000원");
        map.put("item_info","평가률:90%");

        Map<String, Object> map1 = new HashMap<>();
        map1.put("item_displayimage",R.drawable.notebook);
        map1.put("item_title","아이뮤즈 스톰북14 64GB");
        map1.put("item_size","64GB");
        map1.put("item_id","999992");
        map1.put("store_id","9");
        map1.put("store_name","전자기기");
        map1.put("item_money","319,000원");
        map1.put("item_info","평가률:90%");

        Map<String, Object> map2 = new HashMap<>();
        map2.put("item_displayimage",R.drawable.camera);
        map2.put("item_title","폴라로이드 고 카메라 Pro");
        map2.put("item_size","");
        map2.put("item_id","999992");
        map2.put("store_id","9");
        map2.put("store_name","전자기기");
        map2.put("item_money","159,000원");
        map2.put("item_info"," 평가률:90%");

        Map<String, Object> map3 = new HashMap<>();
        map3.put("item_displayimage",R.drawable.microphone);
        map3.put("item_title","휴대용 블루투스 무선마이크");
        map3.put("item_size","");
        map3.put("item_id","999992");
        map3.put("store_id","9");
        map3.put("store_name","전자기기");
        map3.put("item_money","119,800원");
        map3.put("item_info","평가률:90%");

        Map<String, Object> map4 = new HashMap<>();
        map4.put("item_displayimage",R.drawable.charger);
        map4.put("item_title","삼성 3in 1케이블 C타입 충전기");
        map4.put("item_size","");
        map4.put("item_id","999995");
        map4.put("store_id","9");
        map4.put("store_name","전자기기");
        map4.put("item_money","19,900원");
        map4.put("item_info","평가률:90%");

        Map<String, Object> map5 = new HashMap<>();
        map5.put("item_displayimage",R.drawable.keyboard);
        map5.put("item_title","게이밍키보드 블랙위도우");
        map5.put("item_size","");
        map5.put("item_id","999996");
        map5.put("store_id","9");
        map5.put("store_name","전자기기");
        map5.put("item_money","10,900원");
        map5.put("item_info","평가률:90%");

        Map<String, Object> map6 = new HashMap<>();
        map6.put("item_displayimage",R.drawable.usb);
        map6.put("item_title","USB3.1 FlashDrive 32GB");
        map6.put("item_size","32GB");
        map6.put("item_id","999997");
        map6.put("store_id","9");
        map6.put("store_name","전자기기");
        map6.put("item_money","19,900원");
        map6.put("item_info","평가률:90%");

        Map<String, Object> map7 = new HashMap<>();
        map7.put("item_displayimage",R.drawable.router);
        map7.put("item_title","ipTime 무선공유기");
        map7.put("item_size","");
        map7.put("item_id","999998");
        map7.put("store_id","9");
        map7.put("store_name","전자기기");
        map7.put("item_money","64,900원");
        map7.put("item_info","평가률:90%");

        List<HashMap<String, Object>> hashMaps = new ArrayList<>();
        hashMaps.add((HashMap<String, Object>) map);
        hashMaps.add((HashMap<String, Object>) map1);
        hashMaps.add((HashMap<String, Object>) map2);
        hashMaps.add((HashMap<String, Object>) map3);
        hashMaps.add((HashMap<String, Object>) map4);
        hashMaps.add((HashMap<String, Object>) map5);
        hashMaps.add((HashMap<String, Object>) map6);
        hashMaps.add((HashMap<String, Object>) map7);

        return  hashMaps;
    }

    // 通过商品的标签获取商品信息
    public static Bundle getBundle(String item_title){
        Bundle bundle=null;
        for (Map<String, Object> map:data){
            // 获取用户点击的商品,并跳转到商品详情页面
            if (map.get("item_title").equals(item_title)){
                // 传递参数
                //让hashmap实现可序列化则要定义一个实现可序列化的类。
                SerMap serMap=new SerMap();
                //传递map到SerMap 中的map，这样数据就会传递到SerMap 中的map中。
                serMap.setMap((HashMap<String, Object>) map);
                //创建Bundle对象，存放实现可序列化的SerMap
                bundle=new Bundle();
                bundle.putSerializable("listView",serMap);
            }
        }

        return bundle;
    }

}
