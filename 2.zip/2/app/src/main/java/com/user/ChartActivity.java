package com.user;


import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import com.user.R;

public class ChartActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chart);
    }
}