package com.user;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ListView;


import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;

/**
 * @Author xifangzheng
 * Created by zz on 2017/9/26 10:10.
 * 　　class explain:
 * 　　　　update:       upAuthor:      explain:
 */

public class ImageButton3 extends AppCompatActivity {
    private ListView listView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.imagebutton3);

        listView = (ListView) findViewById(R.id.list);

        BaseAdapter arrayAdapter = new ArrayAdapter(this,R.layout.item_list,R.id.name,
                Arrays.asList("사과 할인쿠폰","유기농 현미 할인쿠폰","빈츠 할인쿠폰","정관장 홍삼 할인쿠폰","가전제품 할인쿠폰"));
        ;


        listView.setAdapter(arrayAdapter);


        RingView ringView = (RingView) findViewById(R.id.ringView);

        // 添加的是颜色
        List<Integer> colorList = new ArrayList<>();
        colorList.add(R.color.wheat);
        colorList.add(R.color.aqua);
        colorList.add(R.color.lime);
        colorList.add(R.color.aliceblue);
        colorList.add(R.color.oldlace);
        colorList.add(R.color.mistyrose);
        colorList.add(R.color.royalblue);
        colorList.add(R.color.thistle);
        colorList.add(R.color.lightsteelblue);
        colorList.add(R.color.deepskyblue);
        colorList.add(R.color.burlywood);
        colorList.add(R.color.forestgreen);

        //  添加的是百分比
        List<Float> rateList = new ArrayList<>();
        rateList.add(10f);
        rateList.add(5f);
        rateList.add(8f);
        rateList.add(7f);
        rateList.add(4f);
        rateList.add(9f);
        rateList.add(6f);
        rateList.add(8f);
        rateList.add(10f);
        rateList.add(11f);
        rateList.add(9f);
        rateList.add(13f);
        ringView.setShow(colorList, rateList,false,true);
    }
}

