package com.user;


import android.os.Bundle;

import com.user.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ViewData6 {
    public static   List<HashMap<String,Object>> data = addData();
    // 获取静态数据
    public static List<HashMap<String,Object>> addData() {
        Map<String, Object> map = new HashMap<>();
        map.put("item_displayimage", R.drawable.hobby1);
        map.put("item_title","테니스 라켓 채 스포츠 운동");
        map.put("item_size","2개입");
        map.put("item_id","666661");
        map.put("store_id","6");
        map.put("store_name","취미.운동");
        map.put("item_money","127,700원");
        map.put("item_info","평가률:90%");

        Map<String, Object> map1 = new HashMap<>();
        map1.put("item_displayimage",R.drawable.hobby2);
        map1.put("item_title","크로스 스트랩 발목 보호대");
        map1.put("item_size","1p");
        map1.put("item_id","666662");
        map1.put("store_id","6");
        map1.put("store_name","취미.운동");
        map1.put("item_money","6,210원");
        map1.put("item_info"," 평가률:90%");

        Map<String, Object> map2 = new HashMap<>();
        map2.put("item_displayimage",R.drawable.hobby3);
        map2.put("item_title","아이워너 파워밴드");
        map2.put("item_size","21mm(블루)");
        map2.put("item_id","666663");
        map2.put("store_id","6");
        map2.put("store_name","취미.운동");
        map2.put("item_money","17,700원");
        map2.put("item_info"," 평가률:90%");

        Map<String, Object> map3 = new HashMap<>();
        map3.put("item_displayimage",R.drawable.hobby4);
        map3.put("item_title","레보플렉스 익스트림(전신 운동기구)");
        map3.put("item_size","");
        map3.put("item_id","666664");
        map3.put("store_id","6");
        map3.put("store_name","취미.운동");
        map3.put("item_money","15,000원");
        map3.put("item_info","평가률:90%");

        Map<String, Object> map4 = new HashMap<>();
        map4.put("item_displayimage",R.drawable.hobby5);
        map4.put("item_title","유연성 허리운동 훌라후프");
        map4.put("item_size","");
        map4.put("item_id","666665");
        map4.put("store_id","6");
        map4.put("store_name","취미.운동");
        map4.put("item_money","20,500원");
        map4.put("item_info","평가률:90%");

        Map<String, Object> map5 = new HashMap<>();
        map5.put("item_displayimage",R.drawable.hobby6);
        map5.put("item_title","코어 바이퍼 VIPR운동 용품 기구");
        map5.put("item_size","KG-2K");
        map5.put("item_id","666666");
        map5.put("store_id","6");
        map5.put("store_name","취미.운동");
        map5.put("item_money","49,600원");
        map5.put("item_info"," 평가률:90%");

        Map<String, Object> map6 = new HashMap<>();
        map6.put("item_displayimage",R.drawable.hobby7);
        map6.put("item_title","손목 강화 완력기 근력기 운동기구");
        map6.put("item_size","");
        map6.put("item_id","666667");
        map6.put("store_id","6");
        map6.put("store_name","취미.운동");
        map6.put("item_money","40,700원");
        map6.put("item_info","평가률:90%");

        Map<String, Object> map7 = new HashMap<>();
        map7.put("item_displayimage",R.drawable.hobby8);
        map7.put("item_title","등산 레저 스포츠 눈 보호 선글라스");
        map7.put("item_size","");
        map7.put("item_id","666668");
        map7.put("store_id","6");
        map7.put("store_name","취미.운동");
        map7.put("item_money","33,900원");
        map7.put("item_info"," 평가률:90%");

        List<HashMap<String, Object>> hashMaps = new ArrayList<>();
        hashMaps.add((HashMap<String, Object>) map);
        hashMaps.add((HashMap<String, Object>) map1);
        hashMaps.add((HashMap<String, Object>) map2);
        hashMaps.add((HashMap<String, Object>) map3);
        hashMaps.add((HashMap<String, Object>) map4);
        hashMaps.add((HashMap<String, Object>) map5);
        hashMaps.add((HashMap<String, Object>) map6);
        hashMaps.add((HashMap<String, Object>) map7);

        return  hashMaps;
    }

    // 通过商品的标签获取商品信息
    public static Bundle getBundle(String item_title){
        Bundle bundle=null;
        for (Map<String, Object> map:data){
            // 获取用户点击的商品,并跳转到商品详情页面
            if (map.get("item_title").equals(item_title)){
                // 传递参数
                //让hashmap实现可序列化则要定义一个实现可序列化的类。
                SerMap serMap=new SerMap();
                //传递map到SerMap 中的map，这样数据就会传递到SerMap 中的map中。
                serMap.setMap((HashMap<String, Object>) map);
                //创建Bundle对象，存放实现可序列化的SerMap
                bundle=new Bundle();
                bundle.putSerializable("listView",serMap);
            }
        }

        return bundle;
    }

}
