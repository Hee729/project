package com.user;

import android.content.Context;
import android.util.AttributeSet;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;

/**
 * @description: 超市
 * @author: admin
 * @date: 2022/11/9
 * @email: 1145338587@qq.com
 */
public class SupermarketLayout extends ConstraintLayout {

    private static final String TAG = "SupermarketLayout";

    public SupermarketLayout(Context context) {
        super(context);
    }

    public SupermarketLayout(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);

        for (int i = 0; i < getChildCount(); i++) {
            if (getChildAt(i) instanceof GoodsShelves) {

            }
        }

    }
}