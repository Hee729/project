package com.user;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "Goods")
public class GoodsBean {

    @PrimaryKey()
    @NonNull
    private String goods_id;
    @ColumnInfo(name = "goods_image")
    private String goods_image;
    @ColumnInfo(name = "goods_name")
    private String goods_name;
    @ColumnInfo(name = "goods_num")
    private String goods_num;
    @ColumnInfo(name = "goods_price")
    private String goods_price;
    @ColumnInfo(name = "store_id")
    private String store_id;
    @ColumnInfo(name = "store_name")
    private String store_name;


    public String getStore_name() {
        return store_name;
    }

    public void setStore_name(String store_name) {
        this.store_name = store_name;
    }

    public String getStore_id() {
        return store_id;
    }

    public void setStore_id(String store_id) {
        this.store_id = store_id;
    }

    public String getGoods_id() {
        return goods_id;
    }

    public void setGoods_id(String goods_id) {
        this.goods_id = goods_id;
    }

    public String getGoods_image() {
        return goods_image;
    }

    public void setGoods_image(String goods_image) {
        this.goods_image = goods_image;
    }

    public String getGoods_name() {
        return goods_name;
    }

    public void setGoods_name(String goods_name) {
        this.goods_name = goods_name;
    }

    public String getGoods_num() {
        return goods_num;
    }

    public void setGoods_num(String goods_num) {
        this.goods_num = goods_num;
    }

    public String getGoods_price() {
        return goods_price;
    }

    public void setGoods_price(String goods_price) {
        this.goods_price = goods_price;
    }

}
