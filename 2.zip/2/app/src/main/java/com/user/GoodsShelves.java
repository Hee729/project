package com.user;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Log;

import androidx.appcompat.widget.AppCompatTextView;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * @description: 货架
 * @author: admin
 * @date: 2022/11/9
 * @email: 1145338587@qq.com
 */
public class GoodsShelves extends AppCompatTextView {

    private static final String TAG = "GoodsShelves";

    private List<GoodsPosition> goodsPositionList;

    private String store_id;

    public String getStore_id() {
        return store_id;
    }

    public void setStore_id(String store_id) {
        this.store_id = store_id;
    }

    /* 图片 */
    public int image;

    /* 画笔 */
    public Paint rectPaint, circularPaint, imagePaint;

    /* 文字区域 */
    public Rect textRect, imageRect, mDestRect;

    private int width, height;

    private DecimalFormat decimalFormat;

    public GoodsShelves(Context context) {
        super(context);
    }

    public GoodsShelves(Context context, AttributeSet attrs) {
        super(context, attrs);

        goodsPositionList = new ArrayList<>();
        textRect = new Rect();
        imageRect = new Rect();
        rectPaint = new Paint();
        mDestRect = new Rect();

        circularPaint = new Paint();
        circularPaint.setStyle(Paint.Style.FILL);

        rectPaint.setStyle(Paint.Style.STROKE);
        rectPaint.setStrokeWidth(dpToPx(context, 3));
        rectPaint.setColor(Color.BLACK);

        imagePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        imagePaint.setFilterBitmap(true);
        imagePaint.setDither(true);

        decimalFormat = new DecimalFormat("0.00");
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);

        //测量以后获得子view大小
        width = getMeasuredWidth();
        height = getMeasuredHeight();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        int rectWidth = width >> 1, rectHeight = height >> 1;

        textRect.top = height >> 2;
        textRect.left = width >> 2;
        textRect.bottom = textRect.top * 3;
        textRect.right = textRect.left * 3;

        canvas.drawRect(textRect, rectPaint);

        for (int i = 0; i < goodsPositionList.size(); i++) {

            float pW = 0, pH = 0;
            int imageSide = rectWidth >> 3;

            //根据长宽最小的数值，计算出图片距离文本框的距离
            int marge = Math.min(width, height) >> 4;

            GoodsPosition goodsPosition = goodsPositionList.get(i);
            circularPaint.setColor(goodsPosition.getColor());

            switch (goodsPosition.getDirection()) {
                case GoodsPosition.DIRECTION_TOP:
                    //点的坐标
                    pW = textRect.left + rectWidth * goodsPosition.getLocation();
                    pH = textRect.top;
                    imageRect.top = textRect.top - marge - imageSide;
                    imageRect.left = (int) pW - (imageSide >> 1);
                    imageRect.right = imageRect.left + imageSide;
                    imageRect.bottom = imageRect.top + imageSide;
                    break;
                case GoodsPosition.DIRECTION_LEFT:
                    pW = textRect.left;
                    pH = textRect.bottom - rectHeight * goodsPosition.getLocation();
                    imageRect.top = (int) pH - (imageSide >> 1);
                    imageRect.left = textRect.left - marge - imageSide;
                    imageRect.right = imageRect.left + imageSide;
                    imageRect.bottom = imageRect.top + imageSide;
                    break;
                case GoodsPosition.DIRECTION_BOTTOM:
                    pW = textRect.right - rectWidth * goodsPosition.getLocation();
                    pH = textRect.bottom;
                    imageRect.top = textRect.bottom + marge;
                    imageRect.left = (int) pW - (imageSide >> 1);
                    imageRect.right = imageRect.left + imageSide;
                    imageRect.bottom = imageRect.top + imageSide;
                    break;
                case GoodsPosition.DIRECTION_RIGHT:
                    pW = textRect.right;
                    pH = textRect.top + rectHeight * goodsPosition.getLocation();
                    imageRect.top = (int) pH - (imageSide >> 1);
                    imageRect.left = textRect.right + marge;
                    imageRect.right = imageRect.left + imageSide;
                    imageRect.bottom = imageRect.top + imageSide;
                    break;
            }

            canvas.drawCircle(pW, pH, 10, circularPaint);

            int imageW = goodsPosition.getImage().getWidth();

            goodsPosition.setImage(scaleBitmap(goodsPosition.getImage(), Float.parseFloat(decimalFormat.format(imageSide / (float) imageW))));
            canvas.drawBitmap(goodsPosition.getImage(), imageRect.left, imageRect.top, imagePaint);

        }

    }

    public void setGoodsList(List<GoodsPosition> goodsPositionList) {
        this.goodsPositionList = goodsPositionList;
    }

    /**
     * 按比例缩放图片
     *
     * @param origin 原图
     * @param ratio  比例
     * @return 新的bitmap
     */
    private Bitmap scaleBitmap(Bitmap origin, float ratio) {

        Log.d(TAG, "scaleBitmap() called with: origin = [" + origin + "], ratio = [" + ratio + "]");

        if (origin == null) {
            return null;
        }
        int width = origin.getWidth();
        int height = origin.getHeight();

        Matrix matrix = new Matrix();
        matrix.preScale(ratio, ratio);
        Bitmap newBM = Bitmap.createBitmap(origin, 0, 0, width, height, matrix, false);
        if (newBM.equals(origin)) {
            return newBM;
        }
        origin.recycle();
        return newBM;
    }

    /**
     * 根据手机的分辨率从 dp(相对大小) 的单位 转成为 px(像素)
     */
    public static int dpToPx(Context context, float dpValue) {
        // 获取屏幕密度
        final float scale = context.getResources().getDisplayMetrics().density;
        // 结果+0.5是为了int取整时更接近
        return (int) (dpValue * scale + 0.5f);
    }

    /**
     * 根据手机的分辨率从 px(像素) 的单位 转成为 dp(相对大小)
     */
    public static int pxToDp(Context context, float pxValue) {
        final float scale = context.getResources().getDisplayMetrics().density;
        return (int) (pxValue / scale + 0.5f);
    }

}
