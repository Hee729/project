package com.user;


import android.os.Bundle;

import com.user.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ViewData12 {
    public static   List<HashMap<String,Object>> data = addData();
    // 获取静态数据
    public static List<HashMap<String,Object>> addData() {
        Map<String, Object> map = new HashMap<>();
        map.put("item_displayimage", R.drawable.homerun);
        map.put("item_title","홈런볼 41g*4입");
        map.put("item_size","");
        map.put("item_id","120001");
        map.put("store_id","12");
        map.put("store_name","과자");
        map.put("item_money","3,990원");
        map.put("item_info","평가률:90%");

        Map<String, Object> map1 = new HashMap<>();
        map1.put("item_displayimage",R.drawable.rice);
        map1.put("item_title","쌀과자 300g");
        map1.put("item_size","");
        map1.put("item_id","120002");
        map1.put("store_id","12");
        map1.put("store_name","과자");
        map1.put("item_money","17,760원");
        map1.put("item_info","평가률:90%");

        Map<String, Object> map2 = new HashMap<>();
        map2.put("item_displayimage",R.drawable.hersheys);
        map2.put("item_title","허쉬 초콜릿 쿠기 144g");
        map2.put("item_size","");
        map2.put("item_id","120003");
        map2.put("store_id","12");
        map2.put("store_name","과자");
        map2.put("item_money","39,000원");
        map2.put("item_info","평가률:90%");

        Map<String, Object> map3 = new HashMap<>();
        map3.put("item_displayimage",R.drawable.corn);
        map3.put("item_title","[롯데]꼬깔꼰 고소한맛 134g");
        map3.put("item_size","");
        map3.put("item_id","120004");
        map3.put("store_id","12");
        map3.put("store_name","과자");
        map3.put("item_money","5,400원");
        map3.put("item_info","평가률:90%");

        Map<String, Object> map4 = new HashMap<>();
        map4.put("item_displayimage",R.drawable.bigpie);
        map4.put("item_title","[크라운]빅파이 324g");
        map4.put("item_size","");
        map4.put("item_id","120005");
        map4.put("store_id","12");
        map4.put("store_name","과자");
        map4.put("item_money","4,900원");
        map4.put("item_info","평가률:90%");

        Map<String, Object> map5 = new HashMap<>();
        map5.put("item_displayimage",R.drawable.binch);
        map5.put("item_title","[롯데]빈츠 204g");
        map5.put("item_size","");
        map5.put("item_id","120006");
        map5.put("store_id","12");
        map5.put("store_name","과자");
        map5.put("item_money","6,230원");
        map5.put("item_info","평가률:90%");

        Map<String, Object> map6 = new HashMap<>();
        map6.put("item_displayimage",R.drawable.hill);
        map6.put("item_title","[해태]맛동산 70g");
        map6.put("item_size","");
        map6.put("item_id","120007");
        map6.put("store_id","12");
        map6.put("store_name","과자");
        map6.put("item_money","1,000원");
        map6.put("item_info","평가률:90%");

        Map<String, Object> map7 = new HashMap<>();
        map7.put("item_displayimage",R.drawable.shell);
        map7.put("item_title","[롯데]몽쉘 크림케이크 192g");
        map7.put("item_size","");
        map7.put("item_id","120008");
        map7.put("store_id","12");
        map7.put("store_name","과자");
        map7.put("item_money","1,950원");
        map7.put("item_info","평가률:90%");


        List<HashMap<String, Object>> hashMaps = new ArrayList<>();
        hashMaps.add((HashMap<String, Object>) map);
        hashMaps.add((HashMap<String, Object>) map1);
        hashMaps.add((HashMap<String, Object>) map2);
        hashMaps.add((HashMap<String, Object>) map3);
        hashMaps.add((HashMap<String, Object>) map4);
        hashMaps.add((HashMap<String, Object>) map5);
        hashMaps.add((HashMap<String, Object>) map6);
        hashMaps.add((HashMap<String, Object>) map7);

        return  hashMaps;
    }

    // 通过商品的标签获取商品信息
    public static Bundle getBundle(String item_title){
        Bundle bundle=null;
        for (Map<String, Object> map:data){
            // 获取用户点击的商品,并跳转到商品详情页面
            if (map.get("item_title").equals(item_title)){
                // 传递参数
                //让hashmap实现可序列化则要定义一个实现可序列化的类。
                SerMap serMap=new SerMap();
                //传递map到SerMap 中的map，这样数据就会传递到SerMap 中的map中。
                serMap.setMap((HashMap<String, Object>) map);
                //创建Bundle对象，存放实现可序列化的SerMap
                bundle=new Bundle();
                bundle.putSerializable("listView",serMap);
            }
        }

        return bundle;
    }

}
