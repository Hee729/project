package com.user;


import android.os.Bundle;

import com.user.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ViewData4 {
    public static   List<HashMap<String,Object>> data = addData();
    // 获取静态数据
    public static List<HashMap<String,Object>> addData() {
        Map<String, Object> map = new HashMap<>();
        map.put("item_displayimage", R.drawable.cereals1);
        map.put("item_title","믿고먹는 안심농협 쌀");
        map.put("item_id","444441");
        map.put("store_id","4");
        map.put("store_name","곡류");
        map.put("item_size","20kg");
        map.put("item_money","45,900원");
        map.put("item_info","평가률:90%");

        Map<String, Object> map1 = new HashMap<>();
        map1.put("item_displayimage",R.drawable.cereals2);
        map1.put("item_title","천년의 솜씨 신동진 쌀");
        map1.put("item_size","5kg");
        map1.put("item_id","444442");
        map1.put("store_id","4");
        map1.put("store_name","곡류");
        map1.put("item_money","17,900원");
        map1.put("item_info"," 평가률:90%");

        Map<String, Object> map2 = new HashMap<>();
        map2.put("item_displayimage",R.drawable.cereals3);
        map2.put("item_title","횡성 찹쌀");
        map2.put("item_size","3.8kg");
        map2.put("item_id","444443");
        map2.put("store_id","4");
        map2.put("store_name","곡류");
        map2.put("item_money","19,900원");
        map2.put("item_info","평가률:90%");

        Map<String, Object> map3 = new HashMap<>();
        map3.put("item_displayimage",R.drawable.cereals4);
        map3.put("item_title","유기농 현미");
        map3.put("item_size","3kg");
        map3.put("item_id","444444");
        map3.put("store_id","4");
        map3.put("store_name","곡류");
        map3.put("item_money","19,980원");
        map3.put("item_info","평가률:90%");

        Map<String, Object> map4 = new HashMap<>();
        map4.put("item_displayimage",R.drawable.cereals5);
        map4.put("item_title","서리태(검정콩)");
        map4.put("item_size","700g");
        map4.put("item_id","444445");
        map4.put("store_id","4");
        map4.put("store_name","곡류");
        map4.put("item_money","9,030원");
        map4.put("item_info","평가률:90%");

        Map<String, Object> map5 = new HashMap<>();
        map5.put("item_displayimage",R.drawable.cereals6);
        map5.put("item_title","국내산 카무트");
        map5.put("item_size","1kg");
        map5.put("item_id","444446");
        map5.put("store_id","4");
        map5.put("store_name","곡류");
        map5.put("item_money","9,900원");
        map5.put("item_info"," 평가률:90%");

        Map<String, Object> map6 = new HashMap<>();
        map6.put("item_displayimage",R.drawable.cereals7);
        map6.put("item_title","국내산 혼합 10곡");
        map6.put("item_size"," 4kg");
        map6.put("item_id","444447");
        map6.put("store_id","4");
        map6.put("store_name","곡류");
        map6.put("item_money","14,900원");
        map6.put("item_info","평가률:90%");

        Map<String, Object> map7 = new HashMap<>();
        map7.put("item_displayimage",R.drawable.cereals8);
        map7.put("item_title","검정강낭콩");
        map7.put("item_size","1.5kg");
        map7.put("item_id","444448");
        map7.put("store_id","4");
        map7.put("store_name","곡류");
        map7.put("item_money","6,990원");
        map7.put("item_info","평가률:90%");


        List<HashMap<String, Object>> hashMaps = new ArrayList<>();
        hashMaps.add((HashMap<String, Object>) map);
        hashMaps.add((HashMap<String, Object>) map1);
        hashMaps.add((HashMap<String, Object>) map2);
        hashMaps.add((HashMap<String, Object>) map3);
        hashMaps.add((HashMap<String, Object>) map4);
        hashMaps.add((HashMap<String, Object>) map5);
        hashMaps.add((HashMap<String, Object>) map6);
        hashMaps.add((HashMap<String, Object>) map7);

        return  hashMaps;
    }

    // 通过商品的标签获取商品信息
    public static Bundle getBundle(String item_title){
        Bundle bundle=null;
        for (Map<String, Object> map:data){
            // 获取用户点击的商品,并跳转到商品详情页面
            if (map.get("item_title").equals(item_title)){
                // 传递参数
                //让hashmap实现可序列化则要定义一个实现可序列化的类。
                SerMap serMap=new SerMap();
                //传递map到SerMap 中的map，这样数据就会传递到SerMap 中的map中。
                serMap.setMap((HashMap<String, Object>) map);
                //创建Bundle对象，存放实现可序列化的SerMap
                bundle=new Bundle();
                bundle.putSerializable("listView",serMap);
            }
        }

        return bundle;
    }

}
