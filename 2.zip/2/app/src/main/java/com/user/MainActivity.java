package com.user;


import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;
import me.relex.circleindicator.CircleIndicator3;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentTransaction;
import android.view.MenuItem;
import android.widget.FrameLayout;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {
    private ViewPager2 mPager;
    private final int num_page = 4;
    private CircleIndicator3 mIndicator;
    BottomNavigationView bottomNavigationView;
    Fragment1 fragment1;
    Fragment2 fragment2;
    Fragment3 fragment3;

        @Override
        protected void onCreate (Bundle savedInstanceState){
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);

            //프래그먼트 생성
            fragment1 = new Fragment1();
            fragment2 = new Fragment2();
            fragment3 = new Fragment3();
            //제일 처음 띄워줄 뷰를 세팅해줍니다. commit();까지 해줘야 합니다.




            //버튼1-페이지전환
            Button button1_btn = findViewById(R.id.button1);
            button1_btn.setOnClickListener(view -> {
                Intent intent = new Intent(getApplicationContext(), button1.class);
                startActivity(intent);
            });
            //버튼2-페이지전환
            Button button2_btn = findViewById(R.id.button2);
            button2_btn.setOnClickListener(view -> {
                Intent intent = new Intent(getApplicationContext(), button2.class);
                startActivity(intent);
            });
            //버튼3-페이지 전환
            Button button3_btn = findViewById(R.id.button3);
            button3_btn.setOnClickListener(view -> {
                Intent intent = new Intent(getApplicationContext(), button3.class);
                startActivity(intent);
            });

            //버튼4-페이지 전환
            Button button4_btn = findViewById(R.id.button4);
            button4_btn.setOnClickListener(view -> {
                Intent intent = new Intent(getApplicationContext(), button4.class);
                startActivity(intent);
            });

            //버튼5-페이지 전환
            Button button5_btn = findViewById(R.id.button5);
            button5_btn.setOnClickListener(view -> {
                Intent intent = new Intent(getApplicationContext(), button5.class);
                startActivity(intent);
            });

            //버튼6-페이지 전환
            Button button6_btn = findViewById(R.id.button6);
            button6_btn.setOnClickListener(view -> {
                Intent intent = new Intent(getApplicationContext(), button6.class);
                startActivity(intent);
            });

            //버튼7-페이지 전환
            Button button7_btn = findViewById(R.id.button7);
            button7_btn.setOnClickListener(view -> {
                Intent intent = new Intent(getApplicationContext(), button7.class);
                startActivity(intent);
            });

            //버튼8-페이지 전환
            Button button8_btn = findViewById(R.id.button8);
            button8_btn.setOnClickListener(view -> {
                Intent intent = new Intent(getApplicationContext(), button8.class);
                startActivity(intent);
            });

            //버튼9-페이지 전환
            Button button9_btn = findViewById(R.id.button9);
            button9_btn.setOnClickListener(view -> {
                Intent intent = new Intent(getApplicationContext(), button9.class);
                startActivity(intent);
            });

            //버튼10-페이지 전환
            Button button10_btn = findViewById(R.id.button10);
            button10_btn.setOnClickListener(view -> {
                Intent intent = new Intent(getApplicationContext(), button10.class);
                startActivity(intent);
            });

            //버튼11-페이지 전환
            Button button11_btn = findViewById(R.id.button11);
            button11_btn.setOnClickListener(view -> {
                Intent intent = new Intent(getApplicationContext(), button11.class);
                startActivity(intent);
            });

            //버튼12-페이지 전환
            Button button12_btn = findViewById(R.id.button12);
            button12_btn.setOnClickListener(view -> {
                Intent intent = new Intent(getApplicationContext(), button12.class);
                startActivity(intent);
            });

            //이미지버튼1(경로찾기)-페이지전환
            ImageButton ImageButton1 = findViewById(R.id.ImageButton1);
            ImageButton1.setOnClickListener(view -> {
                Intent intent = new Intent(getApplicationContext(), ImageButton1.class);
                startActivity(intent);
            });

            //이미지버튼2(체크리스트)-페이지전환
            ImageButton ImageButton2 = findViewById(R.id.ImageButton2);
            ImageButton2.setOnClickListener(view -> {
                Intent intent = new Intent(getApplicationContext(), ImageButton2.class);
                startActivity(intent);
            });

            //이미지버튼3(체크리스트)-페이지전환
            ImageButton ImageButton3 = findViewById(R.id.ImageButton3);
            ImageButton3.setOnClickListener(view -> {
                Intent intent = new Intent(getApplicationContext(), ImageButton3.class);
                startActivity(intent);
            });

            //이미지버튼4(로그인)-페이지전환
            ImageView iv_my = findViewById(R.id.iv_my);
            iv_my.setOnClickListener(view -> {
                Intent intent = new Intent(getApplicationContext(), iv_my.class);
                startActivity(intent);
            });

            //이미지버튼5(블루투스)-페이지전환
            ImageView iv_bluetooth = findViewById(R.id.iv_bluetooth);
            iv_bluetooth.setOnClickListener(view -> {
                Intent intent = new Intent(getApplicationContext(), GPSActivity.class);
                startActivity(intent);
            });

            //이미지버튼6(블루투스)-페이지전환
            ImageView iv_beacon = findViewById(R.id.iv_beacon);
            iv_beacon.setOnClickListener(view -> {
                Intent intent = new Intent(getApplicationContext(), Wifi_setting.class);
                startActivity(intent);
            });

            //ViewPager2
            mPager = findViewById(R.id.viewpager);
            //Adapter
            FragmentStateAdapter pagerAdapter = new MyAdapter(this, num_page);
            mPager.setAdapter(pagerAdapter);
            //Indicator
            mIndicator = findViewById(R.id.indicator);
            mIndicator.setViewPager(mPager);
            mIndicator.createIndicators(num_page, 0);
            //ViewPager Setting
            mPager.setOrientation(ViewPager2.ORIENTATION_HORIZONTAL);


            mPager.setCurrentItem(1000); //시작 지점
            mPager.setOffscreenPageLimit(4); //최대 이미지 수

            mPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
                @Override
                public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                    super.onPageScrolled(position, positionOffset, positionOffsetPixels);
                    if (positionOffsetPixels == 0) {
                        mPager.setCurrentItem(position);
                    }


                }
            });

        }
        
}



